#!/bin/bash
touch /tmp/gatesentry-internetupdate
